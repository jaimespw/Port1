package PaqGroupName;

public class Container {
    private int identifierNumber;
    private int weight;
    private String countryOfOrigin;
    private boolean customsInspected;
    private int priorityLevel;
    private String contentDescription;
    private String senderCompany;
    private String receiverCompany;

    public Container(int identifierNumber, int weight, String countryOfOrigin, boolean customsInspected,
                     int priorityLevel, String contentDescription, String senderCompany, String receiverCompany) {
        this.identifierNumber = identifierNumber;
        this.weight = weight;
        this.countryOfOrigin = countryOfOrigin;
        this.customsInspected = customsInspected;
        this.priorityLevel = priorityLevel;
        this.contentDescription = contentDescription;
        this.senderCompany = senderCompany;
        this.receiverCompany = receiverCompany;
    }

    public Container() {
    }

    public int getIdentifierNumber() {
        return identifierNumber;
    }

    public void setIdentifierNumber(int identifierNumber) {
        this.identifierNumber = identifierNumber;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    public boolean isCustomsInspected() {return customsInspected;}
    public void setContentDescription(String contentDescription) {this.contentDescription = contentDescription;}
    public void setCustomsInspected(boolean customsInspected) {this.customsInspected = customsInspected;}

    public String getSenderCompany() {return senderCompany;}
    public String getContentDescription() {return contentDescription;}
    public int getPriorityLevel() {return priorityLevel;}

    public void setPriorityLevel(int priorityLevel) {this.priorityLevel = priorityLevel;}
    public void setReceiverCompany(String receiverCompany) {this.receiverCompany = receiverCompany;}
    public void setSenderCompany(String senderCompany) {this.senderCompany = senderCompany;}

    public String getReceiverCompany() {return receiverCompany;}

    @Override
    public String toString() {
        return "Container [identifierNumber=" + identifierNumber + ", weight=" + weight + ", countryOfOrigin=" +
                countryOfOrigin + ", customsInspected=" + customsInspected + ", priorityLevel=" + priorityLevel
                    + ", contentDescription=" + contentDescription + ", senderCompany=" + senderCompany + ", receiverCompany=" + receiverCompany + "]";
    }
}
