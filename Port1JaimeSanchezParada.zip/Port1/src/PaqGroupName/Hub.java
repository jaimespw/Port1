package PaqGroupName;

public class Hub extends Container {
    private Container[][] storage;
    int prioritylevel;
    private Hub hub;
    int checkedCount = hub.getCheckedContainerCount(prioritylevel);

    public Hub() {storage = new Container[10][12];}

    public void stackContainer(Container container) {
        int priority = container.getPriorityLevel();
        int column = (priority == 1) ? 0 : (priority == 2) ? 1 : 2;

        for (int row = 0; row < 10; row++) {
            if (storage[row][column] == null) {
                storage[row][column] = container;
                break;
            }
        }
    }

    public void removeContainer(int column) {
        for (int row = 0; row < 10; row++) {
            if (storage[row][column] != null) {
                storage[row][column] = null;
            }
        }
    }

    public int checkPrio(int prio){
        if(this.prioritylevel == prio){
            System.out.println("Containers with the same priority " + prioritylevel + ": " + checkedCount);
        }
        else {return 0;}

        return prio;
    }

    private int getCheckedContainerCount(int priority) {
        return 0;
    }


}

